from fastapi import FastAPI, UploadFile, File, Form
from fastapi.responses import FileResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
import uvicorn
import os, uuid, datetime
from typing import List
import pandas as pd

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
STORAGE_DIR = os.path.join(BASE_DIR, 'storage')
os.makedirs(STORAGE_DIR, exist_ok=True)

app = FastAPI(title='ADP Backend')
app.add_middleware(
    CORSMiddleware,
    allow_origins=['*'],
    allow_credentials=True,
    allow_methods=['*'],
    allow_headers=['*'],
)

USERS=[]
UPLOADS=[]
EXTRACTIONS=[]

@app.post('/api/upload')
async def upload_files(user_email: str = Form("demo@user.com"), distributor: str = Form("Default Distributor"), files: List[UploadFile]=File(...)):
    saved=[]
    for f in files:
        uid=str(uuid.uuid4())
        fname=f.filename
        out= os.path.join(STORAGE_DIR, uid+'_'+fname)
        with open(out,'wb') as w: w.write(await f.read())
        saved.append(out)
        UPLOADS.append({'id':uid,'user_email':user_email,'filename':fname,'path':out,'status':'done','uploaded_at':datetime.datetime.utcnow().isoformat()})
        try:
            if fname.lower().endswith(('.xls','.xlsx')):
                df=pd.read_excel(out)
            elif fname.lower().endswith('.csv'):
                df=pd.read_csv(out)
            else:
                continue
            for _,row in df.iterrows():
                EXTRACTIONS.append({
                    'distributor': distributor,
                    'product': str(row.get('Product','')),
                    'opening': float(row.get('Opening',0) or 0),
                    'receipt': float(row.get('Receipt',0) or 0),
                    'sales': float(row.get('Sales',0) or 0),
                    'free_goods': float(row.get('Free Goods', row.get('Free',0)) or 0),
                    'closing': float(row.get('Closing',0) or 0),
                    'uploaded_at': datetime.datetime.utcnow().date().isoformat()
                })
        except:
            pass
    return {'status':'queued','files':[os.path.basename(x) for x in saved]}

@app.get('/api/admin/master')
async def master():
    if not EXTRACTIONS:
        return JSONResponse({'error':'no data'})
    df=pd.DataFrame(EXTRACTIONS)
    agg=df.groupby(['distributor','product'],as_index=False).sum()
    agg=agg.rename(columns={'distributor':'Distributor','product':'Product','opening':'Opening','receipt':'Receipt','sales':'Sales','free_goods':'Free Goods','closing':'Closing'})
    out=os.path.join(STORAGE_DIR,'master.csv')
    agg.to_csv(out,index=False)
    return FileResponse(out,filename='master.csv')

if __name__=='__main__':
    uvicorn.run(app,host='0.0.0.0',port=8000)
